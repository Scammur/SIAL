rm -rf SIALZADA

git clone https://github.com/M4STERMIND1/SIALZADA.git

cd SIALZADA

python SIALXD.py
